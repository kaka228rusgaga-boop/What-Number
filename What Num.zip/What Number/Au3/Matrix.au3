$maxAttempts = InputBox( _
"Настройки", _
"Сколько попыток разрешить?", _
10, "", 300, 150)

If @error Then Exit

; Валидация $maxAttempts
If Not StringIsInt($maxAttempts) Or Int($maxAttempts) <= 0 Then
    $maxAttempts = 10
Else
    $maxAttempts = Int($maxAttempts)
EndIf


; Настройки сложности
$level = InputBox( _
"Настройки", _
"Выбери сложность:" & @CRLF & _
"1 - Ты играть умеешь? (1 – 5)" & @CRLF & _
"2 - Легко (1 – 50)" & @CRLF & _
"3 - Нормально (1 – 100)" & @CRLF & _
"4 - Хардкор (1 – 500)" & @CRLF & _
"5 - Экстрим (1 – 1.000)" & @CRLF & _
"6 - Апокалипсис (1 – 10.000)" & @CRLF & _
"7 - Профи (1 – 100.000)" & @CRLF & _
"8 - Безумие (1 – 1.000.000)" & @CRLF & _
"9 - КАК? (1 – 10.000.000)" & @CRLF & _
"10 - Ты что с ума сошел? (1 – 100.000.000)", _
"", "", 400, 275)

If @error Then Exit

; Валидация $level
If Not StringIsInt($level) Then
    $level = 3
Else
    $level = Int($level)
    If $level < 1 Or $level > 10 Then $level = 3
EndIf

; Значения по умолчанию
$maxNumber = 100

Switch $level

    Case 1 
        $maxNumber = 5

    Case 2
        $maxNumber = 50

    Case 3
        $maxNumber = 100

    Case 4
        $maxNumber = 500

    Case 5
        $maxNumber = 1000
    
    Case 6
        $maxNumber = 10000

    Case 7
        $maxNumber = 100000

    Case 8
        $maxNumber = 1000000

    Case 9
        $maxNumber = 10000000

    Case 10
        $maxNumber = 100000000

    Case Else
        MsgBox(0, "Ошибка", "Неизвестная сложность. Будет режим нормально.")
EndSwitch


; Игра
$secret = Random(1, $maxNumber, 1)
$attempts = 0

; Статистика
$totalGames = 0
$totalWins = 0

; Время начала игры
$startTime = TimerInit()

While 1

    $guess = InputBox( _
    "Угадай число", _
    "Компьютер загадал число от 1 до " & $maxNumber)

    If @error Then Exit

    ; Валидация ввода догадки
    If Not StringIsInt($guess) Then
        MsgBox(0, "Ошибка ввода", "Введите целое число.")
        ContinueLoop
    EndIf

    $guess = Int($guess)
    $attempts += 1

    If $guess < $secret Then
        MsgBox(0, "Подсказка", "Число больше.")

    ElseIf $guess > $secret Then
        MsgBox(0, "Подсказка", "Число меньше.")

    Else
        ; Победа
        $time = Round(TimerDiff($startTime)/1000,1)
        $totalGames += 1
        $totalWins += 1
        MsgBox(0, "Победа!", _
        "Ты угадал число!" & @CRLF & _
        "Попыток: " & $attempts & @CRLF & _
        "Время: " & $time & " сек.")

        MsgBox(0, "Статистика", _
        "Игр: " & $totalGames & @CRLF & _
        "Побед: " & $totalWins)

        Exit
    EndIf

    ; Проверка лимита попыток внутри цикла
    If $attempts >= $maxAttempts And $guess <> $secret Then
        $time = Round(TimerDiff($startTime)/1000,1)
        $totalGames += 1
        MsgBox(0, "Проигрыш", _
        "Попытки закончились!" & @CRLF & _
        "Было загадано число: " & $secret & @CRLF & _
        "Время: " & $time & " сек.")

        MsgBox(0, "Статистика", _
        "Игр: " & $totalGames & @CRLF & _
        "Побед: " & $totalWins)

        Exit
    EndIf

WEnd